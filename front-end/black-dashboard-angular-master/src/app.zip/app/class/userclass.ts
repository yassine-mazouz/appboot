export class Userclass {
  id: number;
  name: string;
  last_name: string;
  email: string;
  deleted: string;
  password : string;
  role : string;
}
